package com.monsterbound.pocketwilds;
import android.app.*;import android.os.*;import android.webkit.*;import android.graphics.Color;import android.view.*;
public class MainActivity extends Activity{
 WebView web;
 public void onCreate(Bundle b){super.onCreate(b);requestWindowFeature(Window.FEATURE_NO_TITLE);getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
 web=new WebView(this);web.setBackgroundColor(Color.rgb(38,61,43));web.setWebViewClient(new WebViewClient());WebSettings w=web.getSettings();w.setJavaScriptEnabled(true);w.setDomStorageEnabled(true);w.setAllowFileAccess(true);web.loadUrl("file:///android_asset/index.html");setContentView(web);}
 @Override public void onBackPressed(){web.evaluateJavascript("if(typeof back==='function')back();",null);}
}