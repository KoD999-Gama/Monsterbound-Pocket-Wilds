# Monsterbound: Pocket Wilds, phone-only build

This package is prepared so the Android build happens on GitHub's servers. You only need your Android phone and a GitHub account.

## Build the APK

1. Create or sign in to GitHub.
2. Create a new repository named something like `monsterbound-pocket-wilds`.
3. Choose **Add file -> Upload files**.
4. Upload the **contents** of this ZIP, including the hidden `.github` folder.
5. Commit to the `main` branch.
6. Open **Actions** in the repository.
7. Select **Build Monsterbound Release**.
8. Tap **Run workflow** if needed.
9. Wait for the workflow to finish successfully.
10. Open the completed run and find **Artifacts**.
11. Download **Monsterbound-Pocket-Wilds-APK**.
12. Extract it and install `app-debug.apk` on your phone.

The APK is a real debug-signed Android APK intended for installation/testing.

## Google Play later

The same workflow also creates an **unsigned AAB**. Google Play requires a properly signed release AAB. Do not upload the unsigned AAB. A release keystore should be created and kept private, then used through GitHub Actions secrets or another secure build system.

## Current release

- App: Monsterbound: Pocket Wilds
- Version: 1.0.0
- Version code: 1
- Target SDK: 36
- Minimum SDK: 23
- Package: com.monsterbound.pocketwilds
- Monster roster: 150 original species
