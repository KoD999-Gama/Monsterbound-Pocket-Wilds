# Monsterbound: Pocket Wilds 1.0.0

This is the finalized phone-build package for the current playable release.

## Included

- 150 original catchable monster species
- Willow Town, Route 1, Azure Lake, Whisper Grove, Elder Summit, Moonlit Hollow
- Wild encounters and trainer battles
- Four-badge progression and Warden finale
- Party and storage box
- Field guide with seen/caught tracking
- XP, leveling and evolution
- Potions and capture capsules
- Save/load and automatic backup
- DEV/creator tools
- Android WebView launcher
- Android 16 / API 36 target
- GitHub Actions build for APK and release AAB output

## Honest release status

The game source is syntax-checked. The APK is compiled by GitHub Actions, not by this chat environment. A Google Play production release still requires the developer's own signing key, Play Console account, store listing, policy declarations, and any testing requirements that apply to that account.
