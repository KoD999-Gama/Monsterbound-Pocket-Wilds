# Monsterbound: Pocket Wilds • Release 1.0.0

Original independent retro creature-collecting RPG.

Release features:
- 150 original catchable species
- Full four-badge campaign
- Warden finale
- Postgame Moonlit Hollow
- Party and storage management
- Field Guide and 150/150 completion goal
- XP, leveling, evolution, type matchups and trainer battles
- Automatic saves with backup
- Android touch/phone support

Google Play release preparation:
- compileSdk 36
- targetSdk 36
- versionCode 1
- versionName 1.0.0

Open this project in Android Studio. For Google Play, generate a signed Android App Bundle (.aab), not just an APK.
