# Monsterbound 1.0.0 Play Store Checklist

1. Create/verify the Google Play developer account.
2. Create the app entry in Play Console.
3. Generate a signed Android App Bundle (.aab) in Android Studio.
4. Complete the store listing, screenshots, icon, category, content rating, Data safety, and privacy details.
5. If this is a new personal developer account, run the required closed test with at least 12 opted-in testers continuously for 14 days before applying for production access.
6. Submit the production-access application after testing.
7. Upload the signed AAB and submit for review.

Important:
- Google Play's target API requirement for new apps is Android 16 / API 36 starting August 31, 2026.
- The game should not use Nintendo, Pokémon, Game Freak, or The Pokémon Company branding, characters, creatures, maps, music, or assets.
- The copyright notice documents the project's original-content claim; it is not a substitute for legal registration or professional legal advice.
